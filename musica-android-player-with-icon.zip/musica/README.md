# musica

A minimal Android local music player built with Kotlin, Jetpack Compose, Material 3 and AndroidX Media3 ExoPlayer.

## Features
- Pick one or multiple audio files from Android's system file picker
- Real audio playback with ExoPlayer
- Play/pause, previous/next and seek controls
- Search imported tracks
- Favorites and imported track list persisted on device
- Dark minimal UI

## Build
Open this folder as an Android project with JDK 17 and Android SDK 35, or use the GitHub Actions workflow supplied separately. Gradle 8.10.2 is used by the workflow.

## Notes
This version plays audio files the user selects from their device. It does not stream or download YouTube/YouTube Music audio. Any future YouTube support must use official permitted playback methods and comply with YouTube's terms and API policies.

## License
MIT. See `LICENSE`.
