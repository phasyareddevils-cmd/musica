package com.musica.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay

private val Bg = Color(0xFF101114)
private val Panel = Color(0xFF1B1D22)
private val Muted = Color(0xFF9699A3)
private val White = Color(0xFFF5F5F7)

data class Track(val uri: String, val title: String, val artist: String, val tint: Color)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val player = ExoPlayer.Builder(this).build()
        setContent { MusicaTheme { MusicaApp(player) } }
    }
    override fun onDestroy() {
        // Player is released by the composable lifecycle.
        super.onDestroy()
    }
}

@Composable
private fun MusicaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = White, onPrimary = Bg, background = Bg,
        onBackground = White, surface = Panel, onSurface = White, secondary = Color(0xFFB8BBC5)), content = content)
}

@Composable
private fun MusicaApp(player: ExoPlayer) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("musica", 0) }
    val tracks = remember {
        mutableStateListOf<Track>().apply {
            prefs.getStringSet("tracks", emptySet())?.forEach { raw ->
                val parts = raw.split("|", limit = 3)
                if (parts.size == 3) add(Track(parts[0], parts[1], parts[2], Color(0xFF53677E)))
            }
        }
    }
    val favorites = remember { mutableStateListOf<String>().apply { addAll(prefs.getStringSet("favorites", emptySet()) ?: emptySet()) } }
    var tab by remember { mutableIntStateOf(0) }
    var current by remember { mutableStateOf<Track?>(null) }
    var playerOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf(false) }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }
    var message by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            if (tracks.none { it.uri == uri.toString() }) {
                val name = runCatching {
                    context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) c.getString(0) else null
                    }
                }.getOrNull()?.substringBeforeLast('.') ?: "Unknown track"
                tracks.add(Track(uri.toString(), name, "Local audio", Color(0xFF53677E)))
            }
        }
        prefs.edit().putStringSet("tracks", tracks.map { "${it.uri}|${it.title}|${it.artist}" }.toSet()).apply()
        if (uris.isNotEmpty()) message = "${uris.size} lagu ditambahkan ke Library"
    }

    fun playTrack(track: Track) {
        current = track
        player.setMediaItem(MediaItem.fromUri(Uri.parse(track.uri)))
        player.prepare()
        player.play()
        playing = true
        playerOpen = true
    }
    fun togglePlay() {
        if (current == null && tracks.isNotEmpty()) playTrack(tracks.first())
        else if (player.isPlaying) player.pause() else player.play()
        playing = player.isPlaying
    }
    fun stepTrack(delta: Int) {
        if (tracks.isEmpty()) return
        val index = tracks.indexOfFirst { it.uri == current?.uri }.let { if (it < 0) 0 else it }
        playTrack(tracks[(index + delta + tracks.size) % tracks.size])
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                duration = player.duration.coerceAtLeast(0L)
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener); player.release() }
    }
    LaunchedEffect(player, current) {
        while (true) {
            position = player.currentPosition.coerceAtLeast(0L)
            duration = player.duration.takeIf { it > 0 } ?: 0L
            playing = player.isPlaying
            delay(500)
        }
    }

    if (playerOpen && current != null) {
        PlayerScreen(current!!, playing, current!!.uri in favorites, position, duration,
            onBack = { playerOpen = false }, onPlay = { togglePlay() },
            onSeek = { player.seekTo(it); position = it },
            onFavorite = {
                if (current!!.uri in favorites) favorites.remove(current!!.uri) else favorites.add(current!!.uri)
                prefs.edit().putStringSet("favorites", favorites.toSet()).apply()
            }, onNext = { stepTrack(1) }, onPrevious = { stepTrack(-1) })
    } else {
        Scaffold(containerColor = Bg, bottomBar = {
            Column {
                if (current != null) MiniPlayer(current!!, playing, { playerOpen = true }, { togglePlay() })
                NavigationBar(containerColor = Bg) {
                    val labels = listOf("Home", "Search", "Library")
                    val icons = listOf(Icons.Outlined.Home, Icons.Outlined.Search, Icons.Outlined.LibraryMusic)
                    labels.forEachIndexed { index, label ->
                        NavigationBarItem(selected = tab == index, onClick = { tab = index },
                            icon = { Icon(icons[index], contentDescription = label) }, label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = White, selectedTextColor = White,
                                unselectedIconColor = Muted, unselectedTextColor = Muted, indicatorColor = Panel))
                    }
                }
            }
        }) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    0 -> HomeScreen(tracks, onAdd = { picker.launch(arrayOf("audio/*")) }, onTrackClick = ::playTrack)
                    1 -> SearchScreen(query, { query = it }, tracks, onAdd = { picker.launch(arrayOf("audio/*")) }, onTrackClick = ::playTrack)
                    else -> LibraryScreen(tracks, favorites.toSet(), onAdd = { picker.launch(arrayOf("audio/*")) }, onTrackClick = ::playTrack)
                }
            }
        }
    }
    if (message != null) {
        LaunchedEffect(message) { delay(2200); message = null }
        SnackbarHost(hostState = remember { SnackbarHostState() }, modifier = Modifier.padding(12.dp))
    }
}

@Composable private fun HomeScreen(tracks: List<Track>, onAdd: () -> Unit, onTrackClick: (Track) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().background(Bg), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Text("YOUR SOUND, YOUR SPACE", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp); Text("musica.", color = White, fontSize = 36.sp, fontWeight = FontWeight.Bold); Text("Music for your moments.", color = Muted) }
        item { Button(onClick = onAdd, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = White, contentColor = Bg)) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(8.dp)); Text("Tambahkan musik dari HP") } }
        item { Text("Recently added", fontSize = 21.sp, fontWeight = FontWeight.Bold) }
        if (tracks.isEmpty()) item { EmptyState("Belum ada musik", "Tambahkan file audio dari penyimpanan HP untuk mulai mendengarkan.") }
        items(tracks, key = { it.uri }) { TrackRow(it) { onTrackClick(it) } }
    }
}

@Composable private fun SearchScreen(query: String, onQueryChange: (String) -> Unit, tracks: List<Track>, onAdd: () -> Unit, onTrackClick: (Track) -> Unit) {
    val results = tracks.filter { it.title.contains(query, true) || it.artist.contains(query, true) }
    Column(Modifier.fillMaxSize().background(Bg).padding(20.dp)) {
        Text("Discover", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = White); Text("Find a sound for every moment.", color = Muted)
        Spacer(Modifier.height(18.dp)); OutlinedTextField(value = query, onValueChange = onQueryChange, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search your songs") }, leadingIcon = { Icon(Icons.Outlined.Search, null) }, singleLine = true, shape = RoundedCornerShape(16.dp))
        Spacer(Modifier.height(16.dp)); Text("Your music", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        if (results.isEmpty()) EmptyState("Tidak ada lagu", "Tambahkan file audio untuk mengisi koleksi musik.", onAdd)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(results, key = { it.uri }) { TrackRow(it) { onTrackClick(it) } } }
    }
}

@Composable private fun LibraryScreen(tracks: List<Track>, favorites: Set<String>, onAdd: () -> Unit, onTrackClick: (Track) -> Unit) {
    val saved = tracks.filter { it.uri in favorites }
    Column(Modifier.fillMaxSize().background(Bg).padding(20.dp)) {
        Text("Your Library", fontSize = 32.sp, fontWeight = FontWeight.Bold); Text("Your personal collection.", color = Muted)
        Spacer(Modifier.height(18.dp)); Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = White, contentColor = Bg)) { Icon(Icons.Filled.Add, null); Text("  Add music") }
        Spacer(Modifier.height(20.dp)); Text("All songs (${tracks.size})", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        if (tracks.isEmpty()) EmptyState("Library masih kosong", "Pilih file MP3 atau audio lain dari HP.", onAdd)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(tracks, key = { it.uri }) { TrackRow(it) { onTrackClick(it) } } }
        if (saved.isNotEmpty()) { Spacer(Modifier.height(20.dp)); Text("Favorites (${saved.size})", fontSize = 20.sp, fontWeight = FontWeight.Bold); saved.forEach { TrackRow(it) { onTrackClick(it) } } }
    }
}

@Composable private fun EmptyState(title: String, subtitle: String, onAdd: (() -> Unit)? = null) {
    Column(Modifier.fillMaxWidth().padding(vertical = 30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Outlined.LibraryMusic, null, tint = Muted, modifier = Modifier.size(42.dp)); Spacer(Modifier.height(10.dp))
        Text(title, color = White, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 13.sp)
        if (onAdd != null) TextButton(onClick = onAdd) { Text("Pilih file audio") }
    }
}

@Composable private fun TrackRow(track: Track, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Artwork(track, 54.dp); Spacer(Modifier.width(13.dp)); Column(Modifier.weight(1f)) {
            Text(track.title, color = White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(track.artist, color = Muted, fontSize = 12.sp)
        }; Icon(Icons.Outlined.PlayCircle, null, tint = Muted)
    }
}

@Composable private fun Artwork(track: Track, size: androidx.compose.ui.unit.Dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(track.tint, track.tint.copy(alpha = .42f)))), contentAlignment = Alignment.Center) {
        Icon(Icons.Filled.GraphicEq, null, tint = White, modifier = Modifier.size(size * .48f))
    }
}

@Composable private fun MiniPlayer(track: Track, playing: Boolean, onOpen: () -> Unit, onPlay: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).clip(RoundedCornerShape(15.dp)).background(Panel).clickable(onClick = onOpen).padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
        Artwork(track, 43.dp); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) {
            Text(track.title, color = White, maxLines = 1, fontWeight = FontWeight.SemiBold); Text(track.artist, color = Muted, fontSize = 11.sp)
        }; IconButton(onClick = onPlay) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play or pause", tint = White) }
    }
}

@Composable private fun PlayerScreen(track: Track, playing: Boolean, favorite: Boolean, position: Long, duration: Long,
    onBack: () -> Unit, onPlay: () -> Unit, onSeek: (Long) -> Unit, onFavorite: () -> Unit, onNext: () -> Unit, onPrevious: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).padding(horizontal = 24.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.KeyboardArrowDown, "Back", tint = White) }; Text("NOW PLAYING", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp); Spacer(Modifier.size(48.dp))
        }
        Spacer(Modifier.weight(.7f)); Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(26.dp)).background(Brush.linearGradient(listOf(track.tint, Color(0xFF171820), track.tint.copy(alpha = .7f)))), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.GraphicEq, null, tint = White, modifier = Modifier.size(110.dp))
        }
        Spacer(Modifier.height(30.dp)); Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(track.title, color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(track.artist, color = Muted, fontSize = 15.sp) }
            IconButton(onClick = onFavorite) { Icon(if (favorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Favorite", tint = if (favorite) Color(0xFFFF7185) else White) }
        }
        Slider(value = if (duration > 0) position.coerceIn(0, duration).toFloat() else 0f, onValueChange = { onSeek(it.toLong()) }, valueRange = 0f..(duration.coerceAtLeast(1L).toFloat()), modifier = Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(time(position), color = Muted, fontSize = 11.sp); Text(time(duration), color = Muted, fontSize = 11.sp) }
        Spacer(Modifier.height(18.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onPrevious) { Icon(Icons.Filled.SkipPrevious, "Previous", tint = White, modifier = Modifier.size(36.dp)) }
            FilledIconButton(onClick = onPlay, modifier = Modifier.size(68.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = White, contentColor = Bg)) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play", modifier = Modifier.size(36.dp)) }
            IconButton(onClick = onNext) { Icon(Icons.Filled.SkipNext, "Next", tint = White, modifier = Modifier.size(36.dp)) }
        }; Spacer(Modifier.weight(.8f))
    }
}

private fun time(ms: Long): String { val total = (ms / 1000).coerceAtLeast(0); return "%d:%02d".format(total / 60, total % 60) }
