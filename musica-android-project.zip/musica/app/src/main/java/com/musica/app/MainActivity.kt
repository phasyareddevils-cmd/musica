package com.musica.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF101114)
private val Panel = Color(0xFF1B1D22)
private val Muted = Color(0xFF9699A3)
private val White = Color(0xFFF5F5F7)

data class Track(
    val title: String,
    val artist: String,
    val tint: Color
)

private val tracks = listOf(
    Track("Blue", "Yung Kai", Color(0xFF395B91)),
    Track("Somebody's Pleasure", "Aziz Hedra", Color(0xFF9D6559)),
    Track("Perfect", "Ed Sheeran", Color(0xFF526D53)),
    Track("Double Take", "Dhruv", Color(0xFF8875A8)),
    Track("Until I Found You", "Stephen Sanchez", Color(0xFFB77E52)),
    Track("Those Eyes", "New West", Color(0xFF596E80))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MusicaTheme { MusicaApp() } }
    }
}

@Composable
private fun MusicaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = White,
            onPrimary = Bg,
            background = Bg,
            onBackground = White,
            surface = Panel,
            onSurface = White,
            secondary = Color(0xFFB8BBC5)
        ),
        content = content
    )
}

@Composable
private fun MusicaApp() {
    var tab by remember { mutableIntStateOf(0) }
    var current by remember { mutableStateOf(tracks.first()) }
    var playing by remember { mutableStateOf(false) }
    var playerOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var favorites by remember { mutableStateOf(setOf<String>()) }

    MaterialTheme {
        if (playerOpen) {
            PlayerScreen(
                track = current,
                playing = playing,
                favorite = current.title in favorites,
                onBack = { playerOpen = false },
                onPlay = { playing = !playing },
                onFavorite = {
                    favorites = if (current.title in favorites) favorites - current.title
                    else favorites + current.title
                },
                onNext = {
                    val i = tracks.indexOf(current)
                    current = tracks[(i + 1) % tracks.size]
                },
                onPrevious = {
                    val i = tracks.indexOf(current)
                    current = tracks[(i - 1 + tracks.size) % tracks.size]
                }
            )
        } else {
            Scaffold(
                containerColor = Bg,
                bottomBar = {
                    Column {
                        MiniPlayer(
                            track = current,
                            playing = playing,
                            onOpen = { playerOpen = true },
                            onPlay = { playing = !playing }
                        )
                        NavigationBar(containerColor = Bg) {
                            val labels = listOf("Home", "Search", "Library")
                            val icons = listOf(
                                Icons.Outlined.Home,
                                Icons.Outlined.Search,
                                Icons.Outlined.LibraryMusic
                            )
                            labels.forEachIndexed { index, label ->
                                NavigationBarItem(
                                    selected = tab == index,
                                    onClick = { tab = index },
                                    icon = { Icon(icons[index], contentDescription = label) },
                                    label = { Text(label) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = White,
                                        selectedTextColor = White,
                                        unselectedIconColor = Muted,
                                        unselectedTextColor = Muted,
                                        indicatorColor = Panel
                                    )
                                )
                            }
                        }
                    }
                }
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    when (tab) {
                        0 -> HomeScreen(onTrackClick = {
                            current = it
                            playerOpen = true
                        })
                        1 -> SearchScreen(
                            query = query,
                            onQueryChange = { query = it },
                            onTrackClick = {
                                current = it
                                playerOpen = true
                            }
                        )
                        else -> LibraryScreen(
                            favorites = favorites,
                            onTrackClick = {
                                current = it
                                playerOpen = true
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(onTrackClick: (Track) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 26.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        item {
            Text("GOOD EVENING", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
            Text("musica.", color = White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
            Text("Music for your moments.", color = Muted, fontSize = 14.sp)
        }
        item {
            Text("Made for you", fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CollectionCard("Daily Mix", "Your favorite sounds", Color(0xFF344D68), Modifier.weight(1f))
                CollectionCard("Chill Vibes", "Slow down and relax", Color(0xFF765D76), Modifier.weight(1f))
            }
        }
        item {
            Text("Recently played", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        items(tracks) { track -> TrackRow(track, onClick = { onTrackClick(track) }) }
    }
}

@Composable
private fun CollectionCard(title: String, subtitle: String, color: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(
            Brush.linearGradient(listOf(color, color.copy(alpha = 0.55f)))
        ).padding(14.dp)
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = White, modifier = Modifier.size(54.dp))
        }
        Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(subtitle, color = White.copy(alpha = 0.72f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun SearchScreen(
    query: String,
    onQueryChange: (String) -> Unit,
    onTrackClick: (Track) -> Unit
) {
    val results = tracks.filter {
        it.title.contains(query, true) || it.artist.contains(query, true)
    }
    Column(Modifier.fillMaxSize().background(Bg).padding(20.dp)) {
        Text("Discover", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = White)
        Text("Find a sound for every moment.", color = Muted)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search songs or artists") },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = White,
                unfocusedBorderColor = Panel,
                focusedTextColor = White,
                unfocusedTextColor = White,
                cursorColor = White
            )
        )
        Spacer(Modifier.height(22.dp))
        Text(if (query.isBlank()) "Popular tracks" else "Search results", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        if (results.isEmpty()) {
            Text("No matching tracks.", color = Muted, modifier = Modifier.padding(top = 18.dp))
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(results) { TrackRow(it, onClick = { onTrackClick(it) }) }
            }
        }
    }
}

@Composable
private fun LibraryScreen(favorites: Set<String>, onTrackClick: (Track) -> Unit) {
    val saved = tracks.filter { it.title in favorites }
    Column(Modifier.fillMaxSize().background(Bg).padding(20.dp)) {
        Text("Your Library", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text("Your personal collection.", color = Muted)
        Spacer(Modifier.height(24.dp))
        Text("Favorite songs (${saved.size})", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (saved.isEmpty()) {
            Text("Your favorites will appear here.\nTap the heart on a track to save it.", color = Muted)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(saved) { TrackRow(it, onClick = { onTrackClick(it) }) }
            }
        }
    }
}

@Composable
private fun TrackRow(track: Track, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Artwork(track, 54.dp)
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(track.artist, color = Muted, fontSize = 12.sp)
        }
        Icon(Icons.Outlined.MoreHoriz, contentDescription = "More", tint = Muted)
    }
}

@Composable
private fun Artwork(track: Track, size: androidx.compose.ui.unit.Dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(12.dp)).background(
            Brush.linearGradient(listOf(track.tint, track.tint.copy(alpha = 0.42f)))
        ),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = White, modifier = Modifier.size(size * 0.48f))
    }
}

@Composable
private fun MiniPlayer(track: Track, playing: Boolean, onOpen: () -> Unit, onPlay: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(15.dp)).background(Panel)
            .clickable(onClick = onOpen).padding(9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Artwork(track, 43.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = White, maxLines = 1, fontWeight = FontWeight.SemiBold)
            Text(track.artist, color = Muted, fontSize = 11.sp)
        }
        IconButton(onClick = onPlay) {
            Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = "Play or pause", tint = White)
        }
    }
}

@Composable
private fun PlayerScreen(
    track: Track,
    playing: Boolean,
    favorite: Boolean,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    onFavorite: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit
) {
    var progress by remember(track.title) { mutableFloatStateOf(0f) }
    Column(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 24.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Back", tint = White) }
            Text("NOW PLAYING", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
            IconButton(onClick = {}) { Icon(Icons.Filled.MoreHoriz, contentDescription = "More", tint = White) }
        }
        Spacer(Modifier.weight(0.7f))
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(26.dp))
                .background(Brush.linearGradient(listOf(track.tint, Color(0xFF171820), track.tint.copy(alpha = 0.7f)))),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = White, modifier = Modifier.size(110.dp))
        }
        Spacer(Modifier.height(30.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(track.title, color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artist, color = Muted, fontSize = 15.sp)
            }
            IconButton(onClick = onFavorite) {
                Icon(
                    if (favorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (favorite) Color(0xFFFF7185) else White
                )
            }
        }
        Spacer(Modifier.height(22.dp))
        Slider(value = progress, onValueChange = { progress = it }, modifier = Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("0:00", color = Muted, fontSize = 11.sp)
            Text("--:--", color = Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onPrevious) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = White, modifier = Modifier.size(36.dp))
            }
            FilledIconButton(
                onClick = onPlay,
                modifier = Modifier.size(68.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = White, contentColor = Bg)
            ) {
                Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = "Play", modifier = Modifier.size(36.dp))
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = White, modifier = Modifier.size(36.dp))
            }
        }
        Spacer(Modifier.weight(0.8f))
    }
}
