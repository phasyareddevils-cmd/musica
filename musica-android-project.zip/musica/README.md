# musica

A minimal, open-source Android music-player UI starter built with Kotlin and Jetpack Compose.

## Requirements
- Android Studio or a compatible Android Gradle environment
- JDK 17
- Android SDK Platform 35
- Gradle 8.10.2 (wrapper distribution configured)

## Build
Open this folder as an Android project, allow Gradle sync, then build the `app` debug variant.

## Current status
This is a functional UI prototype:
- Home, Search, Library and Now Playing screens
- Demo track catalogue
- In-memory favorites
- Mini-player and simulated playback controls

**Audio playback and YouTube integration are not implemented yet.** The play/pause button currently changes UI state only. YouTube Data API provides metadata/search, not direct audio streams. YouTube content must be played using permitted official YouTube playback methods and in compliance with YouTube developer policies.

## Open source
Licensed under MIT. See `LICENSE`.
